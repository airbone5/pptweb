var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});


    const ingredients = [
    {
        "id": "1",
        "item": "Bacon"
    },
    {
        "id": "2",
        "item": "Eggs"
    },
    {
        "id": "3",
        "item": "Milk"
    },
    {
        "id": "4",
        "item": "Butter"
    }
];

router.get('/ingredients', (req, res) =>{
  res.cookie('better', 'aaaaa');
  res.cookie('thing', 'bbbb');  
    res.send(ingredients);
});

//Tutorial 4:

router.get('/login', function (req,res,next){   
  res.render('login')  
})
//這是使用者在login.html 按了按鈕 
router.post('/login', function (req,res,next){   
  var username = req.body.username;
  var pwd = req.body.pwd;
  var user={  
    username:'admin',  
    pwd:123456  
  }  
  if(username==user.username && pwd==user.pwd){
    //設定cookie
    res.cookie("user", {username: username}, {maxAge: 600000 , httpOnly: false});
    res.redirect('index'); 
  }else{
    req.error = '使用者名稱密碼錯誤'
    res.render('login' , req) ;
  }  
  
}) 
/*
router.get('/index', function(req, res, next) {  
  res.render('index');
});
*/

router.get('/index', function(req, res, next) {  
  if(req.cookies.user !== null){
    req.user=req.cookies.user;
  }
  res.render('index', req);
});

module.exports = router;
